import Foundation

class ChatRoomManager
{
    private let network: P2PManager
    private var currentRoom: ChatRoom
    private var username
    
    public init(username:String)
    {
        self.username = username
        network = P2PManager.getInstance()
    }
    
    public function GetAvailableChatRooms() -> [String]
    {
        
    }
}

class P2PManager
{
    private var theInstance:P2PManager;
    
    private init()
    {
        print("Singleton Created")
    }
    
    public function getInstance() -> P2PManager
    {
        if (!self.theInstance)
        {
            self.theInstance = P2PManager()
        }
        
        return self.theInstance
    }
    
    public function getAvailableChatRooms() -> [String]
    {
        
    }
}